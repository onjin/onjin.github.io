#!/usr/bin/env python
import os

os.system("wget http://www.djangoproject.com/download/1.0.2/tarball/")
os.system("tar zxf Django-1.0.2-final.tar.gz")
os.system("rm Django-1.0.2-final.tar.gz")
os.system("mv Django-1.0.2-final tmp")
os.system("mv tmp/django django") 
